package com.joaobrandao.alura.gerenciador_pedidos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GerenciadorPedidosApplicationTests {

	@Test
	void contextLoads() {
	}

}
